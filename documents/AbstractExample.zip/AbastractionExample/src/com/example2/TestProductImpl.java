
package com.example2;

public class TestProductImpl {
    public static void main(String[] args) {
        ProductService productService = new ProductImpl();
        productService.store();
        productService.update();
        productService.delete();
    }
}
