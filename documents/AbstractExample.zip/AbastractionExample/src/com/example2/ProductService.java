
package com.example2;


public interface ProductService {
    public final int PriceUnit = 1;
    
    public boolean store();
    public boolean update();
    public boolean delete();
}
