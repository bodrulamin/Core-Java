
package com.example2;


public class ProductImpl implements ProductService{

    @Override
    public boolean store() {
        System.out.println("Data stored successfully");
        return true;
    }

    @Override
    public boolean update() {
        System.out.println("Data updated successfully");
        return true;
    }

    @Override
    public boolean delete() {
        System.out.println("Data deleted successfully");
        return true;
    }
    
}
