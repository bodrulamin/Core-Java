package com.example;


public class Bajaj extends Bike{

    @Override
    public void run() {
        start("Bajaj is started.");
    }

    @Override
    public void getTyre() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
