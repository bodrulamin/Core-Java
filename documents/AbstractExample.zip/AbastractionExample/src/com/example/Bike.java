
package com.example;

public abstract class Bike {
    
    // non-abstract method
    public void start(String msg){
        System.out.println(msg);
    }
    // non-abstract method
    public void stop(String msg){
        System.out.println(msg);
    }
    
    // abastract method
    public abstract void run();
    public abstract void getTyre();
    // default constructor
    public Bike() {
    }
    
    
}
