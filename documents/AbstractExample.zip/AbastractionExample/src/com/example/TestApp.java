
package com.example;

import java.util.logging.Level;
import java.util.logging.Logger;

public class TestApp {
    public static void main(String[] args) {
       Honda honda = new Honda();
       honda.run();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            Logger.getLogger(TestApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        honda.stop("stopped.");
        
        Bike bike = new Bajaj();
        bike.run();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ex) {
            Logger.getLogger(TestApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        bike.stop("Stopped");
    }
}
